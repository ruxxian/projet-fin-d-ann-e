#include "expression.hpp"
#include "Arbre.hpp"
#include <iostream>
#include <string>
using namespace std;

int main()
{
    //ex1
    string test = "";
    expression calc;
    cout << "ex1:" << endl;
    cout << "expression suffixée: ";
    cin>>test;
    cout << "calculé avec expression sufixée: " << calc.evaluer(test) << endl;

    //ex2
    test = "";
    cout << "ex2:" << endl;
    cout << "expression infixée: ";
    cin>>test; 
    cout << "la forme suffixée: "<< calc.suffixee(test) << endl;
    cout << "calculé avec expression infixée: " << calc.evaluerinfixee(test) << endl;

    //ex3
    test = "";
    cout << "ex3:" << endl;
    cout << "entrez une expression à valeurs réels (utilisez: + - / * ^) ne pas mettre d'espace : ";
    cin >> test; 
    Arbre A(test);
    double result = A.evaluer();
    cout << "calculé avec un arbre: " << result << endl;
    cout << "arbre construit à partir de l'expression";
    A.afficher();

    //ex4
    test="";
    string var="";
    cout << "ex4:" << endl;
    cout << "expression à dériver: ";
    cin >> test;
    cout << "dériver à partir de: ";
    cin >> var;
    Arbre B(test);
    B = (B.derive(var));
    B.afficher();

    return 0;

}
