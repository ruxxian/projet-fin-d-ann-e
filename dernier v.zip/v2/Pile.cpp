#include "Pile.hpp"
#include <string> 
#include <iostream>

using namespace std;
//fonction de la class maillon
maillon::maillon(double x){
    info = x;
    suivant = nullptr;
}

maillon::maillon(string x){
    c = x;
    suivant = nullptr;
}

maillon::~maillon(){
}

//fonction de la classe pile

//constructeur 
Pile::Pile(){
    tete = nullptr;
    nbe = 0;
}

Pile::~Pile(){
    if(tete!=NULL) delete tete;
}


//empiler
void Pile::empiler(double x){
	maillon * p = new maillon(x);
	p->suivant = tete;
	tete = p;
	nbe++;
}

void Pile::empiler(string x){
	maillon * p = new maillon(x);
	p->suivant = tete;
	tete = p;
	nbe++;
}

//depiler
double Pile::dbdepiler() {
    if (vide()) {
        throw out_of_range("PILE VIDE");
    } else {
        maillon *temp = tete;
        double retour = temp->info;
        tete = tete->suivant;
        delete temp;
      	nbe--;
        return retour;
    }
}

string Pile::stdepiler() {
    if (vide()) {
        throw out_of_range("PILE VIDE");
    } else {
        maillon *temp = tete;
        string retour = temp->c;
        tete = tete->suivant;
        delete temp;
      	nbe--;
        return retour;
    }
}

bool Pile::vide(){
    return(!(tete));
}

string Pile::stsommet(){
	if(tete!=NULL){
        string ret = tete->c;
        return(ret);
    }
    return(" ");
}

double Pile::dbsommet(){
	if(tete!=NULL){
        double ret = tete->info;
        return(ret);
    }
    return(0);
}