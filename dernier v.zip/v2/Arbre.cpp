#include <string>
#include <stack>
#include <sstream> 
#include <iostream>
#include <iomanip>
#include "Arbre.hpp"
#include "expression.hpp"
using namespace std;

bool isdbl(const string & s){
    int cpt = 0;
    int len = s.length();
    if (len == 0)return false;
    bool digitfnd = false;
    for (int i = 0; i < len; ++i)
    {
        if (isdigit(s[i]))
        {
            digitfnd=true;
        }else if (s[i] == '.')
        {
            if(cpt++) return false;
        }else{
            return false;
        }
    }
    return digitfnd;
}

//convertir infixe vers suffixe
Arbre::Arbre(string infixe){

	expression calc;
	string sufixee = calc.suffixee(infixe);

	std::stack<noeud*> pile;
	istringstream f(sufixee);
	string h;

	while( f >> h){
        if( h!= "+" && h != "-" && h != "*" && h!="/" && h!="^"){
			//empiler l'opérande
            if (isdbl(h)){
                double d = stod(h);
                pile.push(new noeud(d));
            }else{
                pile.push(new noeud(h,nullptr,nullptr));
            }
		}else{
			noeud* droit = pile.top(); pile.pop();
            noeud* gauche = pile.top(); pile.pop();
            pile.push(new noeud(h, gauche, droit));
		}

	}

	racine = pile.top();
}


//evaluer un arbre
double Arbre::rec_evaluer(noeud*& n) {
    if (!n) return 0; // sécurité

    if (n->type == "f") {
        return n->val; // feuille : retourne la valeur
    } else if (n->type == "o") {
        double g = rec_evaluer(n->fg);
        double d = rec_evaluer(n->fd);

        if(n->ope == "+" ) {
            return g + d;
        }
        else if(n->ope == "-" ) {
            return g - d;
        }
        else if(n->ope == "*" ) {
            return g * d;
        }
        else if(n->ope == "/" ) {
            return g / d;
        }
        else if(n->ope == "^") {
            int p = 1;
            for(int i=0; i<d; i++){
                p*=g;
            }
            return p;
        }
    }
    return 0;
}

bool estvar(string a){
return a != "+" && a != "-" && a != "*" && a != "/" && a != "(" && a != ")" && a != "^";
}

//afficher un arbre
void Arbre::afficher(){
    cout << afficher_rec(racine)<<endl;
}
string Arbre::afficher_rec(noeud*& n){
    if (!n) return ""; // sécurité

    if(n->type == "f"){
        ostringstream oss;  
        oss << setprecision(3) << n->val;      
        return oss.str();    
    }
    else if (n->type == "o")
    {
        if (estvar(n->ope))
        {
            ostringstream out;
            out << n->ope;
            return out.str();
        }
        else{
            if(n->fg != nullptr && n->fd != nullptr){
                string g = afficher_rec(n->fg);
                string d = afficher_rec(n->fd);
                if(n->ope == "-" && g!="0"){
                    return g+"-("+d+")";
                }else if(g=="0"){
                    return "-("+d+")";
                }
                else{
                    return "("+ g + n->ope + d + ")";
                }
            }
        }
    }

    return "\0";
}

//fonction dérivée ex4

noeud* clone(const noeud* n) {
    if (!n) return nullptr;
    noeud* nv = new noeud;
    nv->type = n->type;
    nv->ope = n->ope;
    nv->val = n->val;
    if (n->fg) nv->fg = clone(n->fg);
    if (n->fd) nv->fd = clone(n->fd);
    return nv;
}

noeud* derive_rec(noeud* n, const string& var) {
    if (!n) return nullptr;

    //feuille
    if (n->ope == var) {
        return new noeud{1.0};
    }else if(n->type == "f"){
        // C'est un nombre
        return new noeud{0.0};
    }
    
    //opérateurs
    if (n->ope == "+") {
        return new noeud{"+",
            derive_rec(clone(n->fg), var),
            derive_rec(clone(n->fd), var)
        };
    }else if (n->ope == "-") {
        return new noeud{"-",
            derive_rec(clone(n->fg), var),
            derive_rec(clone(n->fd), var)
        };
    }else if (n->ope == "*") {
        return new noeud{"+", 
            new noeud{"*", derive_rec(n->fg, var), clone(n->fd)},
            new noeud{"*", clone(n->fg), derive_rec(n->fd, var)}
        };
    }else if (n->ope == "/") {
        noeud* u_d_v = new noeud{"*", derive_rec(n->fg, var), clone(n->fd)};
        noeud* u_v_d = new noeud{"*", clone(n->fg), derive_rec(n->fd, var)};
        noeud* num = new noeud{"-", u_d_v, u_v_d};
        noeud* den = new noeud{"*", clone(n->fd), clone(n->fd)};
        return new noeud{"/", num, den};
    }else if (n->ope == "^") {
        // Cas particulier : exposant constant uniquement
        if (n->fd->type == "f") {
            double expo = n->fd->val;
            noeud* new_expo = new noeud{expo - 1};
                
            return new noeud{"*",
                new noeud{expo},
                new noeud{"*", derive_rec(clone(n->fg), var),new noeud{"^", clone(n->fg), new_expo}
                }
            };
        }
    }else{

    }

    return nullptr;
}
//fonction membre
noeud* Arbre::derive(const string& var) {
    return derive_rec(racine, var);
}

/*
noeud* simplifier_rec(noeud* n) {
    if (!n){
        return nullptr;
    }

    if (n->type == "f" || estvar(n->ope)) {
        return clone(n);
    }

    // Simplifier les sous-arbres d'abord
    noeud* g = simplifier_rec(n->fg);
    noeud* d = simplifier_rec(n->fd);

    // Règles de simplification
    if (n->ope == "+") {
        // 0 + x = x
        if (g->type == "f" && g->val == 0) {
            delete g;
            return d;
        }
        // x + 0 = x
        if (d->type == "f" && d->val == 0) {
            delete d;
            return g;
        }
        // Simplification des constantes (a + b = c)
        if (g->type == "f" && d->type == "f") {
            double res = g->val + d->val;
            delete g;
            delete d;
            return new noeud{res};
        }
    }
    else if (n->ope == "*") {
        // 0 * x = 0
        if ((g->type == "f" && g->val == 0) || 
            (d->type == "f" && d->val == 0)) {
            delete g;
            delete d;
            return new noeud{0.0};
        }
        // 1 * x = x
        if (g->type == "f" && g->val == 1) {
            delete g;
            return d;
        }
        // x * 1 = x
        if (d->type == "f" && d->val == 1) {
            delete d;
            return g;
        }
        // Simplification des constantes (a * b = c)
        if (g->type == "f" && d->type == "f") {
            double res = g->val * d->val;
            delete g;
            delete d;
            return new noeud{res};
        }
    }
    else if (n->ope == "^") {
        // x^0 = 1
        if (d->type == "f" && d->val == 0) {
            delete g;
            delete d;
            return new noeud{1.0};
        }
        // x^1 = x
        if (d->type == "f" && d->val == 1) {
            delete d;
            return g;
        }
    }
    else if (n->ope == "-"){
        if (g->type == "f" && g->val == 0) {
            delete g;
            if(d->type == "f"){
                double md = -d->val;
                delete d; 
                return noeud{md};
            }
            else if (d->type == "o" && estvar(d->ope))
            {
                return new noeud{
                    new noeud()
                };
            }

        }
    }

    // Si aucune simplification possible, retourner le noeud original avec ses enfants simplifiés
    return new noeud{n->ope, g, d};
}

noeud* & Arbre::simplifier(){
    return simplifier_rec(racine);
}
*/


