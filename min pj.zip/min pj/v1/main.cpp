#include "expression.hpp"
#include "Arbre.hpp"
#include <iostream>
#include <string>
using namespace std;

int main()
{
    //ex1
    string test = "3.5 3.5 + 3 ^";
    expression calc;
    cout << "expression suffixée: " << test << endl;
    cout << "calculé avec expression sufixée: " << calc.evaluer(test) << endl;

    //ex2
    test = "( 3.5 + 3.5 )^3"; 
    cout << calc.suffixee(test) << endl;
    cout << "calculé avec expression infixée: " << calc.evaluerinfixee(test) << endl;

    //ex3
    string alpha;
    cout<<"entrez une expression (utilisez: + - / *) ne pas mettre d'espace : ";
    cin>>alpha;
    Arbre A(alpha);
    double result = A.evaluer();
    cout << "calculé avec un arbre: " << result << endl;
    A.afficher();
    
    //ex4
    string exp;
    cout<<"ex4 dérive:";
    cin>>exp;
    Arbre B(exp);
    Arbre Bd(B.derive("x"));
    Bd.afficher();
    return 0;

}
